HOW TO INSTALL:
1) Open Google Chrome Browser
2) Go to More Tools > Extensions
3) Enable developer mode in the top right
4) Click "Load unpacked" to load the extension.
5) Select the folder containing the product files (the folder with manifest.json present).